﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSkiiPath
{
    class Program
    {
        public class matrixNode
        {
            public static int mRow = 0;
            public static int mCol = 0;
            public int value;           // Elevation Value.
            public bool visited;        // Flag to check if the node is already computed.
            public int LongPathLength;  // The Evaluated Longest Path length that can be seeked from this node.
            public int LastValueInLP;   // The value of the last node in the longest Path from this node
            public int row;             // Row index of the node
            public int col;             // Col index of the node
            public matrixNode nxtNode;  // Holds next node on the longest Path frm this node

            public matrixNode(int val, int ro, int co)
            {
                value = val;
                visited = false;
                LongPathLength = 1;
                LastValueInLP = val;
                row = ro;
                col = co;
                nxtNode = null;
            }
        }

        public static matrixNode[,] NodeMatrix;
        public enum Direction
        { North, South, East, West };

        public static void GetNextNode(matrixNode curNode, Direction dir)
        {
            int row = curNode.row;
            int col = curNode.col;
            matrixNode nxtNode;
            switch (dir)
            {
                case Direction.North:
                    if (row == 0) { return; }
                    if ((NodeMatrix[row - 1, col]).value < curNode.value)
                    { nxtNode = NodeMatrix[row - 1, col]; break; }
                    else return;

                case Direction.South:
                    if (row == matrixNode.mRow - 1) { return; }
                    if ((NodeMatrix[row + 1, col]).value < curNode.value)
                    { nxtNode = (NodeMatrix[row + 1, col]); break; }
                    else return;

                case Direction.East:
                    if (col == matrixNode.mCol - 1) { return; }
                    if ((NodeMatrix[row, col + 1]).value < curNode.value)
                    { nxtNode = (NodeMatrix[row, col + 1]); break; }
                    else return;

                case Direction.West:
                    if (col == 0) { return; }
                    if ((NodeMatrix[row, col - 1]).value < curNode.value)
                    { nxtNode = (NodeMatrix[row, col - 1]); break; }
                    else return;

                default:
                    return;
            }

            CheckPath(nxtNode);
            EvaluateNode(curNode, nxtNode);
        }

        static public void EvaluateNode(matrixNode curNode, matrixNode nextNode)
        {
            if (curNode.LongPathLength < (nextNode.LongPathLength + 1))
            {
                curNode.LongPathLength = nextNode.LongPathLength + 1;
                curNode.LastValueInLP = nextNode.LastValueInLP;
                curNode.nxtNode = nextNode;

            }
            else if (curNode.LongPathLength == nextNode.LongPathLength+1)
            {
                if (curNode.LastValueInLP > nextNode.LastValueInLP)
                {
                    curNode.LastValueInLP = nextNode.LastValueInLP;
                    curNode.nxtNode = nextNode;
                }

            }
        }

        static public void CheckPath(matrixNode curNode)
        {
            if (curNode.visited == true)
            {
                return;
            }

            Program.GetNextNode(curNode, Direction.North);

            Program.GetNextNode(curNode, Direction.South);

            Program.GetNextNode(curNode, Direction.East);

            Program.GetNextNode(curNode, Direction.West);

            curNode.visited = true;
            return;
        }

        // NOTE: The program expects matrix input file to have all element in the following format
        //1) First line should have row and column 
        //2) All elements of row must be in same line seperated by single space.

        static void Main(string[] args)
        {
            string fileName;
            if (args.Length == 0)
            {
                Console.WriteLine("Do you want to use the default input map? enter Y or N");
                char option;
                option = Console.ReadLine()[0];

                if(option == 'Y' || option =='y')
                {
                    fileName = "testMap.txt";
                }
                else
                {
                    Console.WriteLine("Enter the InputFile path");
                    fileName = Console.ReadLine();
                }

            }
            else
            {
                fileName = args[0];
            }

            string line;
            DateTime time1 = DateTime.Now;
            //Console.WriteLine("Start Time" + DateTime.Now());
            // Read the file.
            try
            {
                System.IO.StreamReader file =
                new System.IO.StreamReader(fileName);

                //read the first line and parse the expected row and colomna
                line = file.ReadLine();
                matrixNode.mRow = int.Parse(line.Split(' ')[0]);
                matrixNode.mCol = int.Parse(line.Split(' ')[1]);

                //Handle rong input value

                //Initialize the matrix;
                Program.NodeMatrix = new matrixNode[matrixNode.mRow, matrixNode.mCol];
                string[] arr = new string[matrixNode.mRow];
                for (int i = 0; i < matrixNode.mCol; i++)
                {
                    line = file.ReadLine();

                   // Console.WriteLine(line);
                    arr = line.Split(' ');
                    for (int j = 0; j < matrixNode.mRow; j++)
                    {
                        NodeMatrix[i, j] = new matrixNode(int.Parse(arr[j]), i, j);
                    }

                }
                file.Close();

                //Console.ReadLine();
                //outputting the matrix: comment out later.
                //for (int i = 0; i < matrixNode.mRow; i++)
                //{
                //    for (int j = 0; j < matrixNode.mCol; j++)
                //    {
                //        Console.Write(NodeMatrix[i, j].value + " ");
                //    }
                //    Console.WriteLine();

                //}
                // Console.ReadLine();

                matrixNode finalNode = null;
                int finalLP = 0;
                int finalDepth = 0;
                for (int i = 0; i < matrixNode.mRow; i++)
                {
                    for (int j = 0; j < matrixNode.mCol; j++)
                    {
                        Program.CheckPath(NodeMatrix[i, j]);
                        if (NodeMatrix[i, j].LongPathLength > finalLP)
                        {
                            finalLP = NodeMatrix[i, j].LongPathLength;
                            finalDepth = NodeMatrix[i, j].value - NodeMatrix[i, j].LastValueInLP;
                            finalNode = NodeMatrix[i, j];

                        }
                        else if (NodeMatrix[i, j].LongPathLength == finalLP)
                        {
                            if (finalDepth < (NodeMatrix[i, j].value - NodeMatrix[i, j].LastValueInLP))
                            {
                                finalDepth = (NodeMatrix[i, j].value - NodeMatrix[i, j].LastValueInLP);
                                finalNode = NodeMatrix[i, j];
                            }

                        }

                    }

                }
                DateTime time2 = DateTime.Now;
                TimeSpan t = time2 - time1;
                Console.WriteLine(time1);
                Console.WriteLine(time2);
                Console.WriteLine("total compute Time taken in Seconds:" + t.TotalSeconds);
                //Display the output
                Console.WriteLine("FinalLength :" + finalLP);
                Console.WriteLine("FinalDepth:" + finalDepth);
                Console.WriteLine("Final long path is: ");
                matrixNode node = finalNode;
                while (node != null)
                {
                    Console.WriteLine(node.value + " [" + node.row + "," + node.col + "]");
                    node = node.nxtNode;
                }
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.Data);
                Console.ReadLine();
                return;
            }
        }


    }

}
